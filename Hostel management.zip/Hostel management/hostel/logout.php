<?php
session_start();
unset($_SESSION['id']);
session_destroy();
header('Location:index.php');
?>
<link rel="stylesheet" href="css/style1.css">